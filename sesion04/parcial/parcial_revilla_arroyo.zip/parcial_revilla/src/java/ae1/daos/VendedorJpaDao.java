package ae1.daos;

import ae1.beans.VendedorTO;
import ae1.service.VendedorService;

/**
 *
 * @author Net
 */
public class VendedorJpaDao implements VendedorService{

    public VendedorTO validar(String user, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int cambiarPassword(String psOld, String psNew) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
